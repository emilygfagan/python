from kivy.app import App
from kivy.uix.widget import Widget
from kivy.properties import ObjectProperty
from kivy.lang import Builder
from kivy.core.window import Window
import math

# Set app size
Window.size = (500, 700)
Window.clearcolor = (1, 1, 1, 1)

# Design file
Builder.load_file('calc.kv')

class MyLayout(Widget):
    memory = 0  # Initialize memory to 0

    def clear(self):
        self.ids.calc_input.text = '0'

    # Button press function
    def button_press(self, button):
        history = self.ids.calc_input.text
        if "Error" in history:
            history = ''
        if history == '0':
            self.ids.calc_input.text = f'{button}'
        else:
            self.ids.calc_input.text = f'{history}{button}'

    # Backspace function
    def remove(self):
        history = self.ids.calc_input.text
        self.ids.calc_input.text = history[:-1]

    # Toggle negative function
    def pos_neg(self):
        history = self.ids.calc_input.text
        if '-' in history:
            self.ids.calc_input.text = history.replace("-", "")
        else:
            self.ids.calc_input.text = f'-{history}'

    # Decimal function
    def period(self):
        history = self.ids.calc_input.text
        if '.' not in history:
            self.ids.calc_input.text = f'{history}.'

    # Percent function
    def percent(self):
        history = self.ids.calc_input.text
        try:
            # Convert the current text input to a percentage
            result = float(history) * 0.01
            self.ids.calc_input.text = str(result)
        except ValueError:
            # Handle the case where the input is not a number
            self.ids.calc_input.text = "Error"

    # Math sign function
    def math_sign(self, sign):
        history = self.ids.calc_input.text
        self.ids.calc_input.text = f'{history}{sign}'

    # Memory Clear
    def memory_clear(self):
        self.memory = 0

    # Memory Recall
    def memory_recall(self):
        self.ids.calc_input.text = str(self.memory)

    # Memory Add
    def memory_add(self):
        try:
            self.memory += float(self.ids.calc_input.text)
        except ValueError:
            self.ids.calc_input.text = "Error"

    # Memory Subtract
    def memory_subtract(self):
        try:
            self.memory -= float(self.ids.calc_input.text)
        except ValueError:
            self.ids.calc_input.text = "Error"

    # Square root function
    def square_root(self):
        history = self.ids.calc_input.text
        try:
            sq = math.sqrt(float(history))
            self.ids.calc_input.text = str(sq)
        except:
            self.ids.calc_input.text = "Error"

    # Square function
    def square(self):
        history = self.ids.calc_input.text
        try:
            sq = float(history) ** 2
            self.ids.calc_input.text = str(sq)
        except:
            self.ids.calc_input.text = "Error"

    # Cube function
    def cube(self):
        history = self.ids.calc_input.text
        try:
            cube = float(history) ** 3
            self.ids.calc_input.text = str(cube)
        except:
            self.ids.calc_input.text = "Error"

    # Power function
    def power(self):
        history = self.ids.calc_input.text
        # Check if the history ends with an incomplete exponentiation operation
        if history.endswith("**"):
            self.ids.calc_input.text = "Error: Enter exponent"
        else:
            # Append '**' to the current input to allow the user to enter the exponent
            self.ids.calc_input.text = f'{history}**'

    # Evaluate function
    def equals(self):
        history = self.ids.calc_input.text
        try:
            result = eval(history)
            self.ids.calc_input.text = str(result)
        except:
            self.ids.calc_input.text = "Error"

class CalculatorApp(App):
    def build(self):
        return MyLayout()

if __name__ == '__main__':
    CalculatorApp().run()